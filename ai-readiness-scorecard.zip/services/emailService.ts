import { UserInfo, UserResults } from '../types';

export const sendResultsToEmail = async (userInfo: UserInfo, results: UserResults): Promise<boolean> => {
  console.log('Email service temporarily disabled for deployment.');
  return true;
};