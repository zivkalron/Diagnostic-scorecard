import { UserInfo, UserResults } from '../types';

export const saveToGoogleSheet = async (
  userInfo: UserInfo, 
  results: UserResults, 
  answers: Record<number, number>
): Promise<void> => {
  console.log('Google Sheets service temporarily disabled for deployment.');
  return;
};